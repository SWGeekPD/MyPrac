import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItsmComponent } from './itsm.component';
import { RouterTestingModule } from '@angular/router/testing';
describe('ItsmComponent', () => {
  let component: ItsmComponent;
  let fixture: ComponentFixture<ItsmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [ItsmComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItsmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
