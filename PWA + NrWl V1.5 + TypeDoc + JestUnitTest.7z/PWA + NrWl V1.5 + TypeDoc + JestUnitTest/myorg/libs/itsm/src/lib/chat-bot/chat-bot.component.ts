import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'global-chat-bot',
  templateUrl: './chat-bot.component.html',
  styleUrls: ['./chat-bot.component.scss']
})
export class ChatBotComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
