import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'global-itsm',
  templateUrl: './itsm.component.html',
  styleUrls: ['./itsm.component.scss']
})
export class ItsmComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
