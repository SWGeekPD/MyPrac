import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { KnowledgeSearchComponent } from './knowledge-search/knowledge-search.component';
import { LiveChatComponent } from './live-chat/live-chat.component';
import { CreateTicketComponent } from './create-ticket/create-ticket.component';
import { ItsmComponent } from './itsm.component';
import { ChatBotComponent } from './chat-bot/chat-bot.component';
// Mylib2Module is publishable lib module , but this is also override the mylib view.
// import { Mylib2Module } from '../../../mylib2/src/lib/mylib2.module';
// import { Mylib1View1Component } from '../../../mylib1/src/lib/view1/view1.component';
// tslint:disable-next-line: nx-enforce-module-boundaries
import { RoleGuard } from '../../../core/src/lib/guards/role-guard.service';
// tslint:disable-next-line: nx-enforce-module-boundaries
import { AuthService } from '../../../core/src/lib/services/auth.service';
@NgModule({
  imports: [
    CommonModule,
    // Mylib1Module,
    // Mylib2Module,
    RouterModule.forChild([
      { path: '', pathMatch: 'full', component: ItsmComponent },
      {
        path: 'knowlege-search',
        pathMatch: 'full',
        component: KnowledgeSearchComponent
      },
      { path: 'live-chat', pathMatch: 'full', component: LiveChatComponent },
      {
        path: 'create-ticket',
        pathMatch: 'full',
        component: CreateTicketComponent
      },
      {
        path: 'chat-bot',
        pathMatch: 'full',
        component: ChatBotComponent,
        data: { role: 'Admin' },
        canActivate: [RoleGuard]
      }
      // to load mylib1 route
      // { path: 'mylib1', loadChildren: '@global/mylib1#Mylib1Module' }
    ])
  ],
  providers: [RoleGuard, AuthService],
  // entryComponents:[Mylib1View1Component],
  declarations: [
    KnowledgeSearchComponent,
    LiveChatComponent,
    CreateTicketComponent,
    ItsmComponent,
    ChatBotComponent
  ]
})
export class ITSMModule {}
