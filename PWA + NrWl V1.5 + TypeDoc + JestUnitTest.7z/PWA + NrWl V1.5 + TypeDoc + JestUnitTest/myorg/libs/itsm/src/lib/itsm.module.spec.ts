import { async, TestBed } from '@angular/core/testing';
import { ITSMModule } from './itsm.module';

describe('ITSMModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ITSMModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(ITSMModule).toBeDefined();
  });
});
