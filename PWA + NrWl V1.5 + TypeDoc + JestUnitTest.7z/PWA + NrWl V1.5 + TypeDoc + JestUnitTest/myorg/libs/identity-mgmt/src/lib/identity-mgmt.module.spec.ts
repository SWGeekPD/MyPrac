import { async, TestBed } from '@angular/core/testing';
import { IdentityMgmtModule } from './identity-mgmt.module';

describe('IdentityMgmtModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [IdentityMgmtModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(IdentityMgmtModule).toBeDefined();
  });
});
