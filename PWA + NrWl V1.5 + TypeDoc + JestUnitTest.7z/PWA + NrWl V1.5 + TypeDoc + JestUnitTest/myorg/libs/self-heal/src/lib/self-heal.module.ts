import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Mylib2View1Component } from './view1/view1.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild([
      { path: '', pathMatch: 'full', component: Mylib2View1Component },
      { path: 'view1', pathMatch: 'full', component: Mylib2View1Component }
    ])
  ],
  declarations: [Mylib2View1Component],
  exports: [Mylib2View1Component]
})
export class SelfHealModule {}
