import { async, TestBed } from '@angular/core/testing';
import { SelfHealModule } from './self-heal.module';

describe('SelfHealModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SelfHealModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(SelfHealModule).toBeDefined();
  });
});
