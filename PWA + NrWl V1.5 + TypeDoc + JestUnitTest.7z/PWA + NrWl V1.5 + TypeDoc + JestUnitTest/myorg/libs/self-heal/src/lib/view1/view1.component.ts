import { Component, OnInit } from '@angular/core';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'mylib2-view1',
  templateUrl: './view1.component.html',
  styleUrls: ['./view1.component.scss']
})
export class Mylib2View1Component implements OnInit {
  constructor() {}

  ngOnInit() {}
}
