const express = require('express');
const webpush = require('web-push');
const cors = require('cors');
const bodyParser = require('body-parser');

const VAPID_PUBLIC =
  'BJf_S0ssq5m_4Hx32OFea4prAiSWq6yb792gTp1ooQI6Bke6yj5rY8z4ULtH9ECcazzYU8FBPmgd8yMMjrd-VEk';

const VAPID_PRIVATE = 'VfqfY_K2XzlHzw0JLJG8DI9wOI3101yzydbssr17ehQ';

const fakeDatabase = [];

const app = express();

app.use(cors());
app.use(bodyParser.json());

webpush.setVapidDetails(
  'mailto:pratul.dubey@mindtree.com',
  VAPID_PUBLIC,
  VAPID_PRIVATE
);

app.post('/subscription', (req, res) => {
  const subscription = req.body;
  fakeDatabase.push(subscription);
});

app.post('/sendNotification', (req, res) => {
  const notificationPayload = {
    notification: {
      title: 'New Notification',
      body: 'This is the body of the notification'
    }
  };

  const promises = [];
  fakeDatabase.forEach(subscription => {
    promises.push(
      webpush.sendNotification(
        subscription,
        JSON.stringify(notificationPayload)
      )
    );
  });
  Promise.all(promises).then(() => res.sendStatus(200));
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});
