module.exports = {
  name: 'b2c',
  preset: '../../jest.config.js',
  coverageDirectory: '../../coverage/apps/b2c/',
  snapshotSerializers: [
    'jest-preset-angular/AngularSnapshotSerializer.js',
    'jest-preset-angular/HTMLCommentSerializer.js'
  ]
};
