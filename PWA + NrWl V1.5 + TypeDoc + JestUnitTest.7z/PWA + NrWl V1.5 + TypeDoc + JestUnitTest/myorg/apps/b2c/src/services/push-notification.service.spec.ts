import { TestBed } from '@angular/core/testing';

import { PushNotificationService } from './push-notification.service';
import { HttpClientModule } from '@angular/common/http';
describe('PushNotificationService', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [HttpClientModule]
    })
  );

  it('should be created', () => {
    const service: PushNotificationService = TestBed.get(
      PushNotificationService
    );
    expect(service).toBeTruthy();
  });
});
