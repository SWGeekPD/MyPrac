import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { SelfHealModule } from '@global/self-heal';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { IdentityMgmtModule } from '@global/identity-mgmt';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { ITSMModule } from '@global/itsm';
import { HttpClientModule } from '@angular/common/http';
import { APP_BASE_HREF } from '@angular/common';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(
      [
        { path: '', loadChildren: '@global/identity-mgmt#IdentityMgmtModule' },
        { path: 'itsm', loadChildren: '@global/itsm#ITSMModule' },
        { path: 'selfheal', loadChildren: '@global/self-heal#SelfHealModule' }
      ],
      { initialNavigation: 'enabled' }
    ),
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production
    })
  ],
  providers: [{ provide: APP_BASE_HREF, useValue: '/b2c' }],
  bootstrap: [AppComponent]
})
export class AppModule {}
