module.exports = {
  name: 'b2b',
  preset: '../../jest.config.js',
  coverageDirectory: '../../coverage/apps/b2b/',
  snapshotSerializers: [
    'jest-preset-angular/AngularSnapshotSerializer.js',
    'jest-preset-angular/HTMLCommentSerializer.js'
  ]
};
