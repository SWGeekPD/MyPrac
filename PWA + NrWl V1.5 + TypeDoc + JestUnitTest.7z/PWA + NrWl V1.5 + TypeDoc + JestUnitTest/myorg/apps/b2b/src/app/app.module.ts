import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { SelfHealModule } from '@global/self-heal';
import { IdentityMgmtModule } from '@global/identity-mgmt';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { ITSMModule } from '@global/itsm';
import { CoreModule } from '@global/core';
// import { PushNotificationService } from '../services/push-notification.service';
import { HttpClientModule } from '@angular/common/http';
import { APP_BASE_HREF } from '@angular/common';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    HttpClientModule,
    // IdentityMgmtModule, -- lazy loaded module must not import else you will get error
    // SelfHealModule,
    RouterModule.forRoot(
      [
        { path: '', loadChildren: '@global/identity-mgmt#IdentityMgmtModule' },
        { path: 'itsm', loadChildren: '@global/itsm#ITSMModule' },
        { path: 'selfheal', loadChildren: '@global/self-heal#SelfHealModule' }
      ],
      { initialNavigation: 'enabled' }
    ),
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production
    })
  ],
  providers: [{ provide: APP_BASE_HREF, useValue: '/b2b' }],
  bootstrap: [AppComponent]
})
export class AppModule {}
