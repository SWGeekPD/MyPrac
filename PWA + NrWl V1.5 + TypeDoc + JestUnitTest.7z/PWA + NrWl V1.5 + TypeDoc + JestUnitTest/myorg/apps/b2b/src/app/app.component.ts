import { Component } from '@angular/core';
import { SwPush } from '@angular/service-worker';
// import { PushNotificationService } from '../services/push-notification.service';

const VAPID_PUBLIC =
  'BJf_S0ssq5m_4Hx32OFea4prAiSWq6yb792gTp1ooQI6Bke6yj5rY8z4ULtH9ECcazzYU8FBPmgd8yMMjrd-VEk';

@Component({
  selector: 'global-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'B2B Portal';

  constructor(swPush: SwPush) {
    if (swPush.isEnabled) {
      swPush
        .requestSubscription({
          serverPublicKey: VAPID_PUBLIC
        })
        .then(subscription => {
          // send subscription to the server
          // below service backend server not working
          // pushService.sendSubscriptionToTheServer(subscription).subscribe();
        })
        .catch(console.error);
    }
  }

  logout() {}
}
